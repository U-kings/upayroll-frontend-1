import React, { useEffect, useState } from "react";
import cookie from "js-cookie";
import { Link, useHistory } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { SignoutButton } from "..";
import {
  TopHeader,
  ProfileContainer,
  ProfileContent,
} from "../../styles/library";

const Header = ({
  isopen9,
  setisopen9,
  text,
  userRole,
  userRoleName,
  profileimg,
}) => {
  const history = useHistory();
  const [isOpen, setIsOpen] = useState(false);
  const [buttonDisabled, setButtonDisabled] = useState(false);
  const [companyLogo] = useState(cookie.get("companyLogo"));

  //   toggle func for modals
  const toggling = () => setIsOpen(!isOpen);

  // close modal
  const close = () => {
    if (isOpen === true) {
      setIsOpen(false);
    }
  };

  const toggling9 = () => setisopen9(!isopen9);

  let profileText = "";
  if (userRole) {
    if (userRole === "HR") {
      profileText = userRoleName;
    } else if (userRole === "CEO") {
      profileText = userRoleName;
    } else if (userRole === "Internal Auditor") {
      profileText = userRoleName;
    } else if (userRole === "Accountant") {
      profileText = userRoleName;
    } else if (userRole === "Employee") {
      profileText = userRoleName;
    }
  }

  useEffect(() => {
    const cookieHR = cookie.get("hr");
    const cookieIA = cookie.get("ia");
    const cookieCEO = cookie.get("ceo");
    const cookieACCT = cookie.get("acct");

    if (
      !JSON.parse(cookieHR ? cookieHR : true) &&
      !JSON.parse(cookieIA ? cookieIA : true) &&
      !JSON.parse(cookieCEO ? cookieCEO : true) &&
      !JSON.parse(cookieACCT ? cookieACCT : true)
    ) {
      return setButtonDisabled(true);
    }
  }, [history]);

  return (
    <>
      <TopHeader onClick={close} isOpen={isopen9}>
        <div className="row">
          <div style={{ display: "none" }} className="menu">
            <FontAwesomeIcon
              className="icons"
              onClick={toggling9}
              icon={["fas", "bars"]}
            />
          </div>
          <h1>{text}</h1>
        </div>
        <div className="row align__center">
          <div className="row margin__right">
            <img src={companyLogo} width="50rem" />
          </div>
          <h2 onClick={toggling}>{profileText}</h2>
          <ProfileContainer onClick={toggling}>
            <img alt="profile" className="profile__img" src={profileimg} />
            {isOpen && (
              <ProfileContent>
                <div className="content">
                  <div className="row">
                    <img
                      alt="profile"
                      className="profile__img2"
                      src={profileimg}
                    />
                  </div>

                  <Link to="/profile-settings">
                    <input
                      type="button"
                      className="settings"
                      value="Profile Settings"
                    />
                  </Link>
                  {(userRole === "HR" || userRole === "CEO") &&
                    !buttonDisabled && (
                      <h3
                        style={{
                          padding: ".5rem",
                          marginBottom: "1rem",
                          fontSize: "2.5rem",
                        }}
                        className="row save__btn"
                      >
                        <Link
                          style={{
                            color: "#fff",
                            // padding: "1rem",
                            margin: "auto",
                            // width: "100%",
                            fontWeight: "400",
                          }}
                          // className="full__width save__btn"
                          to="create-user-roles"
                        >
                          Create User Roles
                        </Link>
                      </h3>
                    )}
                  <SignoutButton />
                </div>
              </ProfileContent>
            )}
          </ProfileContainer>
        </div>
      </TopHeader>
    </>
  );
};

export default Header;
