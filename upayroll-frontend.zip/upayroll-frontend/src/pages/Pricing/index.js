import React from "react";

const Pricing = () => {
  return <>Pricing</>;  
};

export default Pricing;
