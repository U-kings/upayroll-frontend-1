import React, { useEffect, useRef, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import * as XLSL from "xlsx";
import { BackLink, Container } from "../../styles/library";
import { COLORS } from "../../values/colors";
import { getAllDepartment } from "../../actions/department";
import { adminGetAllPosition } from "../../actions/position";
import {
  adminCreateBulkEmployeeFunc,
  // hrUploadBulkContractStaffFunc,
} from "../../actions/employee";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { useHistory } from "react-router-dom";
import {
  // downloadContractBulkEmployeeTemplateExcelFileFunc,
  downloadCreateBulkEmployeeTemplateExcelFileFunc,
} from "../../actions/download";
import { Spinner, Successful } from "../../modals";
import { ErrorBox } from "../../components";
import { ADMIN_CREATE_BULK_EMPLOYEE_RESET } from "../../types/employee";
import { DOWNLOADING_ON_PROCESS_ERROR } from "../../types/download";
import { formatDate } from "../../hooks/functions";
const ImportExcelfile = () => {
  // useDispatch init
  const dispatch = useDispatch();
  // history init
  const history = useHistory();

  const [excelFile, setExcelFile] = useState(null);
  const [excelData, setExcelData] = useState([]);
  const [fileName, setFileName] = useState(null);
  const [showError, setShowError] = useState(null);

  // redux state
  const { adminInfo } = useSelector((state) => state.adminLoginStatus);
  const { isLoading: downloadLoading, error: downloadError } = useSelector(
    (state) => state.downloadStatus
  );
  const {
    isLoading: createBulkLoading,
    success: createBulkSuccess,
    error: createBulkError,
  } = useSelector((state) => state.adminCreateBulkEmployee);

  useEffect(() => {
    if (!adminInfo?.isAuthenticated && !adminInfo?.user?.name) {
      history.push("/");
    } else {
      dispatch(getAllDepartment());
      dispatch(adminGetAllPosition());
    }
  }, [dispatch, adminInfo, history]);

  useEffect(() => {
    if (excelFile !== null) {
      const workbook = XLSL.read(excelFile, { type: "buffer" });
      const worksheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[worksheetName];
      const data = XLSL.utils.sheet_to_json(worksheet);
      setExcelData(data);
    }
  }, [excelFile]);

  useEffect(() => {
    if (showError) {
      setTimeout(() => {
        setShowError(null);
      }, 5000);
    }
  }, [showError]);

  const popup7 = () => {
    if (createBulkSuccess && !createBulkError) {
      setExcelData(null);
      setExcelFile(null);
      dispatch({ type: ADMIN_CREATE_BULK_EMPLOYEE_RESET });
      history.push("dashboard");
    }
  };

  // useEffect(() => {
  //   if (
  //     (createBulkSuccess && !createBulkError)
  //   ) {
  //     setExcelData(null);
  //     setExcelFile(null);
  //     dispatch({ type: ADMIN_CREATE_BULK_EMPLOYEE_RESET });
  //     dispatch({ type: HR_UPLOAD_CONTRACT_EMPLOYEE_RESET });
  //     history.push("dashboard");
  //   }
  // }, [
  //   createBulkSuccess,
  //   createBulkError,
  //   dispatch,
  //   history,
  // ]);

  // handle File

  useEffect(() => {
    if (downloadError) {
      dispatch({ type: DOWNLOADING_ON_PROCESS_ERROR });
    }
  }, [dispatch, downloadError]);

  const fileType = ["application/vnd.ms-excel"];
  const fileType2 = [
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  ];
  const handleFile = (e) => {
    let selectedFile = e.target.files[0];

    setFileName(selectedFile?.name);

    if (selectedFile) {
      if (
        selectedFile &&
        (fileType.includes(selectedFile.type) ||
          fileType2.includes(selectedFile.type))
      ) {
        let reader = new FileReader();
        reader.readAsArrayBuffer(selectedFile);
        reader.onload = (e) => {
          setExcelFile(e.target.result);
        };
      } else {
        setShowError("Please select only specified file type");
      }
    } else {
      setShowError("Please select a file");
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // getDepartment();
  };

  const hiddenFileInput = useRef(null);

  const handleClick = () => {
    hiddenFileInput.current.click();
  };

  const downloadTemplate = () => {
    dispatch(downloadCreateBulkEmployeeTemplateExcelFileFunc());
  };

  // const downloadContractTemplate = () => {
  //   dispatch(downloadContractBulkEmployeeTemplateExcelFileFunc());
  // };

  function excelDateToJSDate(excelDate) {
    let date = new Date(Math.round((excelDate - (25568 + 1)) * 86400 * 1000));
    let converted_date = date.toLocaleString();

    // console.log(converted_date);
    // console.log(new Date(converted_date).toISOString());

    // return new Date(converted_date);
    return new Date(converted_date).toISOString();
  }

  const onCreateBulk = () => {
    let newData;
    // if (type && type === "Contract") {
    newData = excelData?.map((el) => {
      return {
        name: el?.StaffName?.trim(),
        staffId: el?.StaffID?.trim(),
        email: el?.Email?.trim(),
        // department: el?.Department ? el?.Department?.trim() : null,
        position: el?.Position ? el?.Position?.trim() : null,
        salaryGrade: el?.SalaryGrade ? el?.SalaryGrade?.trim() : null,
        salaryLevel: el?.SalaryLevel ? el?.SalaryLevel?.trim() : null,
        salaryStep: el?.SalaryStep ? el?.SalaryStep?.trim() : null,
        contractSalary: Number(el.ContractSalary),
        notch: el?.Notch ? el?.Notch : null,
        bankName: el?.BankName?.trim(),
        employeeBankAcctNumber: el?.EmployeeBankAcctNumber?.toString().trim(),
        nationality: el?.Nationality?.trim(),
        gender: el?.Gender?.trim(),
        address: el?.Address?.trim(),
        dob: excelDateToJSDate(el?.Dob),
        mobile: el?.Mobile?.toString().trim(),
        city: el?.City?.trim(),
        state: el?.State?.trim(),
        employeeType: el?.EmploymentType?.trim(),
        joinDate: excelDateToJSDate(el?.JoinDate),
      };
    });

    dispatch(adminCreateBulkEmployeeFunc(newData));
    // dispatch(hrUploadBulkContractStaffFunc(newData));
  };

  // 1999-08-23T00:00:00.495Z
  // 2000-08-23T00:00:00.495Z

  return (
    <>
      {((downloadLoading && !downloadError) || createBulkLoading) && (
        <Spinner />
      )}
      {createBulkSuccess && !createBulkError && (
        <Successful
          isOpen7={createBulkSuccess && !createBulkError}
          popup7={popup7}
          message="Successfully Uploaded Employees"
        />
      )}
      <Container>
        <BackLink className="green__btn" to="/new-employee">
          <FontAwesomeIcon
            className="left__arrow"
            icon={["fas", "arrow-left"]}
          />
        </BackLink>
        <div className="container__content">
          <h1 className="import__text">
            Import
            <span
              style={{
                color: `${COLORS.green}`,
                fontSize: "2.2rem",
                margin: "0 .7rem",
              }}
            >
              Excel
            </span>
            File
          </h1>
        </div>
        <div className="exportfile__container">
          {((!downloadLoading && downloadError) ||
            (!createBulkLoading && createBulkError)) && (
            <ErrorBox errorMessage={downloadError || createBulkError} />
          )}
          <form onSubmit={handleSubmit}>
            {/* <p
              style={{
                color: `${COLORS.red}`,
                marginBottom: "1rem",
                fontSize: "2rem",
                textAlign: "center",
              }}
            >
              &#9888;{" "}
              <u
                style={{
                  fontSize: "1.5rem",
                }}
              >
                Only Contract Staff Bulk Upload Available
              </u>
            </p> */}
            <label>
              Select a file to import: ...*
              <span style={{ color: `${COLORS.red}`, fontSize: "1.3rem" }}>
                (must be a .xls, .xlsx or .csv file extension)
              </span>
            </label>
            {showError && <ErrorBox errorMessage={showError} />}
            <div className="upload_empfile">
              <p className="choose__btn" onClick={handleClick}>
                Choose a file
              </p>
              <p>{fileName}</p>
            </div>
            <input
              type="file"
              ref={hiddenFileInput}
              onChange={handleFile}
              accept=".xls,.xlsx,.csv"
              style={{ display: "none" }}
            />
            <div className="button__row button__left">
              <input
                type="submit"
                className={
                  !excelFile
                    ? "disabled__btn full__width"
                    : "full__width green__btn"
                }
                onClick={() => onCreateBulk()}
                disabled={!excelFile}
                value="Import Excel File"
              />
            </div>
            <p
              style={{
                color: `${COLORS.black5}`,
                marginTop: "1rem",
                fontSize: "1.5rem",
              }}
            >
              Download Excel Template
            </p>
            <div className="button__row margin__top">
              {/* <input
                type="submit"
                className="disabled__btn"
                // className="save__btn"
                onClick={downloadTemplate}
                value="Non-Contract Staff"
              /> */}
              <input
                type="submit"
                className="save__btn"
                // className="save__btn margin__left"
                onClick={downloadTemplate}
                value="Download"
                // value="Contract Staff"
              />
            </div>
          </form>
        </div>
      </Container>
    </>
  );
};

export default ImportExcelfile;
