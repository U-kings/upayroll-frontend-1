export const trancateWord = (string) => {
  if (string) {
    return string.replace(/(.{20})..+/, "$1…");
  }
};

export const removeExtraSpace = (str) => {
  if (str) {
    return str.trim().split(/ +/).join(" ");
  }
};

export const formatDate = (date) => {
  if (date !== "") {
    return new Date(date).toISOString();
  }
};

export const paystructureFormatter = (jsonDoc) => {
  const outPutFormat = {};

  const numberOfSalaryLevels = jsonDoc?.map((el) => {
    if (el["staffGrade"] === jsonDoc[0]["staffGrade"]) {
      return {
        salaryLevel: el["salaryLevel"],
      };
    }
  });

  const formatSalarylevels = [];

  for (let y = 0; y < numberOfSalaryLevels.length; y++) {
    const element = numberOfSalaryLevels[y];
    if (!formatSalarylevels?.includes(element.salaryLevel)) {
      formatSalarylevels?.push(element.salaryLevel);
    }
  }

  outPutFormat.data = [];

  for (let x = 0; x < formatSalarylevels.length; x++) {
    const currentSalaryLevel = formatSalarylevels[x];
    // console.log(currentSalaryLevel);
    const salaryLevelData = jsonDoc.filter(
      (el) => el["salaryLevel"] === currentSalaryLevel
    );

    const curSalaryLevelSteps = salaryLevelData.map((el) => {
      const notches = [];
      const numberOfNotches = Object.keys(el).filter((el2) =>
        el2?.toLowerCase().startsWith("notch")
      );

      for (let z = 0; z < numberOfNotches?.length; z++) {
        const curNotches = numberOfNotches[z];
        notches.push({
          name: curNotches,
          amount: el[curNotches],
        });
      }

      const allEmpty = notches?.every((el) => el.amount === 0);

      return {
        name: el["Steps"],
        amount: el["Step Amount"],
        notches: allEmpty ? [] : notches,
      };
    });

    outPutFormat.data.push({
      salaryLevel: currentSalaryLevel,
      steps: curSalaryLevelSteps,
    });
  }
  return outPutFormat.data;
};
