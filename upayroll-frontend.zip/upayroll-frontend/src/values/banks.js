
export const banks = [
    { name: "Access Bank PLC", value: "Access Bank PLC", id: "Access Bank PLC" },
    { name: "CitiBank Nigeria Ltd", value: "CitiBank Nigeria Ltd", id: "CitiBank Nigeria Ltd" },
    { name: "Diamond Bank Plc", value: "Diamond Bank Plc", id: "Diamond Bank Plc" },
    { name: "EcoBank Nigeria Plc", value: "EcoBank Nigeria Plc", id: "EcoBank Nigeria Plc" },
    { name: "Fidelity Bank Plc", value: "Fidelity Bank Plc", id: "Fidelity Bank Plc" },
    { name: "First Bank Nigeria Ltd", value: "First Bank Nigeria Ltd", id: "First Bank Nigeria Ltd" },
    { name: "First City Monument Bank Plc", value: "First City Monument Bank Plc", id: "First City Monument Bank Plc" },
    { name: "Guarantee Trust Bank Plc", value: "Guarantee Trust Bank Plc", id: "Guarantee Trust Bank Plc" },
    { name: "Heritage Banking Company Ltd", value: "Heritage Banking Company Ltd", id: "Heritage Banking Company Ltd" },
    { name: "Key Stone Bank", value: "Key Stone Bank", id: "Key Stone Bank" },
    { name: "Polaris Bank", value: "Polaris Bank", id: "Polaris Bank" },
    { name: "Providus Bank", value: "Providus Bank", id: "Providus Bank" },
    { name: "Stanbic IBTC Bank Ltd", value: "Stanbic IBTC Bank Ltd", id: "Stanbic IBTC Bank Ltd" },
    { name: "Standard Chartered Bank Nigeria Ltd", value: "Standard Chartered Bank Nigeria Ltd", id: "Standard Chartered Bank Nigeria Ltd" },
    { name: "Sterling Bank Plc", value: "Sterling Bank Plc", id: "Sterling Bank Plc" },
    { name: "SunTrust Bank Nigeria Limited", value: "SunTrust Bank Nigeria Limited", id: "SunTrust Bank Nigeria Limited" },
    { name: "Union Bank of Nigeria Plc", value: "Union Bank of Nigeria Plc", id: "Union Bank of Nigeria Plc" },
    { name: "United Bank For Africa Plc", value: "United Bank For Africa Plc", id: "United Bank For Africa Plc" },
    { name: "Unity Bank Plc", value: "Unity Bank Plc", id: "Unity Bank Plc" },
    { name: "Wema Bank Plc", value: "Wema Bank Plc", id: "Wema Bank Plc" },
    { name: "Zenith Bank Plc", value: "Zenith Bank Plc", id: "Zenith Bank Plc" }
  ]